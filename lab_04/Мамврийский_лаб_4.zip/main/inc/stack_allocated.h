#ifndef _STACK_ALLOCATED_H_
#define _STACK_ALLOCATED_H_

#include "main.h"

char *allocated_array(int size_array);
void free_array_stack(array_stack_t *array_stack);

#endif
