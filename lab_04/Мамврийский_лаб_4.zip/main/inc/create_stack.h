#ifndef _CREATE_STACK_H_
#define _CREATE_STACK_H_

#include "main.h"

int create_array_stack(array_stack_t *array_stack);
int create_list_array(list_stack_t **list_stack, size_t *size_list);

#endif
