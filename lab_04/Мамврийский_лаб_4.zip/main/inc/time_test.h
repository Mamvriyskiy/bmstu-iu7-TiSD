#ifndef _TIME_H_
#define _TIME_H_

void time_test();
void time_machine(array_stack_t *stack_array, list_stack_t **stack_list, int i);

#endif 

