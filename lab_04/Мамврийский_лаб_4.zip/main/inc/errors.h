#ifndef _ERRORS_H_
#define _ERRORS_H_


#define OK 0

#endif
