#ifndef _PRINT_STACK_H_
#define _PRINT_STACK_H_

void print_array_stack(array_stack_t *stack_array);
void print_list_array(list_stack_t *head_list);
int print_free_areas(free_areas_t *free_areas);

#endif
