gcc -std=c99 -Werror -g3 -c ./*.c
gcc -o app.exe ./*.o -lm
