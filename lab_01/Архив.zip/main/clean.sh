#!/bin/bash

rm -f main.c.gcov
rm -f gcov.out
rm -f a.out
rm -f main.o
rm -f main.gcda
rm -f main.gcno
rm -f app.exe
rm -f func_tests/data/out_1.txt
rm -f func_tests/scripts/log.txt 
rm -f output.txt
rm -f func_tests/data/out.txt
rm -f func.c.gcov
rm -f func.gcda
rm -f func.gcno
rm -f func.o
rm -f func_tests/scripts/error.txt
rm -f product_array_func.c.gcov
rm -f product_array_func.gcno
rm -f product_array_func.o
rm -f product_func.c.gcov
rm -f product_func.gcno
rm -f product_func.o
rm -f check_number.o