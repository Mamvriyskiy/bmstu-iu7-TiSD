#ifndef ERROR_H
#define ERROR_H

#include <stdio.h>

#define OK 0

#define FLAG -25
#define NEGATIVE_INPUT_NUMBER -1
#define NEGATIVE_POWER -2
#define UNRIGHT_NUMBER -3
#define UNRIGHT_LEN_NUMBER -4

#endif
